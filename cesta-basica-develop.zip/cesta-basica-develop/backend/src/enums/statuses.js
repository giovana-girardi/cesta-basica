export const statuses = {
  1: 'Esperando recebimento',
  2: 'Entregue para líder',
  3: 'Entregando',
  4: 'Completo',
  5: 'Devolvido',
  6: 'Extraviado'
}
