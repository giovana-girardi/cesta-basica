export const statusesVoucher = {
  1: 'Recebido pelo líder',
  2: 'Entregue',
  3: 'Não Entregue'
}
