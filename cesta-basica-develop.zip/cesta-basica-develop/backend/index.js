/* eslint-disable */
require = require('esm')(module)
module.exports = require('./src/main')
