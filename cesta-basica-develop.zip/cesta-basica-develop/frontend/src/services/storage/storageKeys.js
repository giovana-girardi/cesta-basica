export const keys = {
  GLOBAL_STORE: '_globalStore',
  CHECK_LIST: '_checklist',
}
