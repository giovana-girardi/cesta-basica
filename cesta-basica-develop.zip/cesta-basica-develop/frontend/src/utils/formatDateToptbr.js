export const formatDate = (date) => new Date(date).toLocaleDateString('pt-BR')
