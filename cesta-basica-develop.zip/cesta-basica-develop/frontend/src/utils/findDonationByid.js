export const findDonation = (store, donationId) => store.donationList.find((item) => item.donationId === donationId)
