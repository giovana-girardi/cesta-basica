export const LinkTypes = {}
