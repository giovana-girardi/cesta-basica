import Legend from './Legend'
import { LegendTypes } from './LegendTypes'

export { Legend, LegendTypes }
