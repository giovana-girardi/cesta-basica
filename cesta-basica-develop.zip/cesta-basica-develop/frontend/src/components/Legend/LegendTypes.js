export const LegendTypes = {
  STRONG: 'strong',
  NORMAL: 'normal',
  LIGHT: 'light',
  CENTER: 'center',
  START: 'start',
  END: 'end',
  SIZE_LARGE: 'large',
}
