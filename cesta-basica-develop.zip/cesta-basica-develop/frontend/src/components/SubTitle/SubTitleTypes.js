export const SubTitleTypes = {
  SMALL: 'small',
  LARGE: 'large',
  MEDIUM: 'medium',
  STRONG: 'strong',
  NORMAL: 'normal',
  LIGHT: 'light',
  SIZE_LARGE: 'size-large',
  SIZE_MEDIUM: 'size-medium',
  SIZE_SMALL: 'size-small',
}
