import SubTitle from './SubTitle'
import { SubTitleTypes } from './SubTitleTypes'

export { SubTitle, SubTitleTypes }
