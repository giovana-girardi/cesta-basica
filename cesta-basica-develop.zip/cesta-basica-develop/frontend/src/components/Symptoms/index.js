import Symptoms from './Symptoms'

export { Symptoms }
