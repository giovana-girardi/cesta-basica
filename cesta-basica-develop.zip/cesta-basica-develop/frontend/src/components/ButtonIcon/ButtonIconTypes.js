export const ButtonIconTypes = {
  FILL: 'fill',
  OUTLINE: 'outline',
  LARGE: 'large',
  MEDIUM: 'medium',
  SMALL: 'small',
}
