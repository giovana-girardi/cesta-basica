import Terms from './Terms'

export { Terms }
