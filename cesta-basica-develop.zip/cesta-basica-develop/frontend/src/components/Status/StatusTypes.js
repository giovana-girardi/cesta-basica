export const StatusTypes = {
  COMPLETE: 'complete',
  IN_PROGRESSIVE: 'in-progressive',
}
