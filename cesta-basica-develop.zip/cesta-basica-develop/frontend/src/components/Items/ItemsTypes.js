export const ItemsTypes = {
  SYMPTOMS: 'symptoms',
  BASKET: 'basket',
  SELECT: 'select',
  SMALL: 'small',
  MEDIUM: 'medium',
  LARGE: 'large',
  START: 'start',
  CENTER: 'center',
  END: 'end',
}
