export const gived = 'Entrege'
export const dontGived = 'Não entregue'
