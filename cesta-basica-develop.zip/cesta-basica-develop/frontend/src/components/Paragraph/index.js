import Paragraph from './Paragraph'
import { ParagraphTypes } from './ParagraphTypes'

export { Paragraph, ParagraphTypes }
