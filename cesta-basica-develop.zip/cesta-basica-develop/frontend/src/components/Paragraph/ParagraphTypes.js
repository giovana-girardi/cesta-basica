export const ParagraphTypes = {
  STRONG: 'strong',
  NORMAL: 'normal',
  LIGHT: 'light',
  SMALL: 'small',
  MEDIUM: 'medium',
  LARGE: 'large',
  BOLD: 'bold',
  ITALIC: 'italic',
}
