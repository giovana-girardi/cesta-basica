export const ButtonTypes = {
  FILL: 'fill',
  FILLHOME: 'fillhome',
  OUTLINE: 'outline',
  LARGE: 'large',
  MEDIUM: 'medium',
  SMALL: 'small',
  THIN: 'thin',
}
