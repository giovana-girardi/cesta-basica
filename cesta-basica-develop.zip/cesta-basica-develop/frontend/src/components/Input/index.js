import Input from './Input'
import { inputTypes } from './InputTypes'

export { Input, inputTypes }
