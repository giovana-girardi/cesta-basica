export const inputTypes = {
  TEXT: 'text',
  PASSWORD: 'password',
  CPF: 'cpf',
  CELPHONE: 'celphone',
  SIZE_LARGE: 'large',
  NUMBER: 'number',
}
