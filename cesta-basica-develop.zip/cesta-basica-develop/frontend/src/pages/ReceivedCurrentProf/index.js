import ReceivedCurrentProf from './ReceivedCurrentProf'

export { ReceivedCurrentProf }
