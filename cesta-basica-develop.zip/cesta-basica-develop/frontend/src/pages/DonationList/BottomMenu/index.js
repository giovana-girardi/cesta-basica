import BottomMenu from './BottomMenu'

export { BottomMenu }
